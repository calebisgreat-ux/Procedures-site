// Set your new link here. This can be any URL or path you control.
// Example: window.NEW_LINK = "https://yourdomain.com/procedures";
window.NEW_LINK = "";
